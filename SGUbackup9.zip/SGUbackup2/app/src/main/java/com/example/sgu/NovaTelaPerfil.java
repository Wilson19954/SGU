package com.example.sgu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class NovaTelaPerfil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_tela_perfil);
    }
}
package com.example.sgu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CadastrarProjeto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_projeto);
    }
}